self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "28835d8fe296135ebb7871889424d18a",
    "url": "/index.html"
  },
  {
    "revision": "d900f1a94c45d35094dd",
    "url": "/static/css/2.2cfa1b23.chunk.css"
  },
  {
    "revision": "62bfe5466c7a8e897848",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "d900f1a94c45d35094dd",
    "url": "/static/js/2.9b4c04e7.chunk.js"
  },
  {
    "revision": "d705cb622423d72c5defbf368ca70dcc",
    "url": "/static/js/2.9b4c04e7.chunk.js.LICENSE"
  },
  {
    "revision": "62bfe5466c7a8e897848",
    "url": "/static/js/main.293c73c3.chunk.js"
  },
  {
    "revision": "b2f91e10f3deb5dd19d1",
    "url": "/static/js/runtime-main.89e49d2a.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);